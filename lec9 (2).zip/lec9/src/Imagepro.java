
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class Imagepro extends Frame {

    BufferedImage img, img1;

    Imagepro() {

        try {
            File f = new File("C:\\lec9\\flowers.jpg");
            File f1 = new File("C:\\lec9\\dumboelephant.jpg");
            img = ImageIO.read(f);
            img1 = ImageIO.read(f1);
            int W = img.getWidth();
            int H = img.getHeight();
            int W1 = img1.getWidth();
            int H1 = img1.getHeight();
            for (int y = 0; y < H; y++) {
                for (int x = 0; x < W; x++) {
                    int pixel = img.getRGB(x, y);
                    int red = (pixel >> 16) & 0xFF;
                    int green = (pixel >> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;
                    red = 255 - red;
                    green = 255 - green;
                    blue = 255 - blue;
                    pixel = 0xFF << 24 | red << 16 | green << 8 | blue;
                    img.setRGB(x, y, pixel);

                }
            }
            for (int y = 0; y < H1; y++) {
                for (int x = 0; x < W1; x++) {
                    int pixel = img1.getRGB(x, y);
                    int red = (pixel >> 16) & 0xFF;
                    int green = (pixel >> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;
                    int avg = (red + blue + green) / 3;
                    red = avg;
                    green = avg;
                    blue = avg;
                    pixel = 0xFF << 24 | red << 16 | green << 8 | blue;
                    img1.setRGB(x, y, pixel);

                }
            }

        } catch (IOException ex) {
            Logger.getLogger(Imagepro.class.getName()).log(Level.SEVERE, null, ex);
        }
        setSize(1000, 1000);
        setVisible(true);
    }

    public void paint(Graphics g) {
        g.drawImage(img, 0, 0, 300, 300, this);
        g.drawImage(img1, 350, 0, 300, 300, this);
    }

    public static void main(String[] args) {
        new Imagepro();
    }
}
