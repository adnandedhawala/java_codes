
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class photoedit extends Frame implements MouseListener ,MouseMotionListener{

    BufferedImage img;
    File f;
    int oldx, curx, oldy, cury;
    int iw, ih;
    
    
    photoedit() {
        try {
            f = new File("C:\\lec9\\flowers.jpg");
            img = ImageIO.read(f);

            iw = img.getWidth();
            ih = img.getHeight();
            
            addMouseListener(this);
            //addMouseMotionListener(this);

            setSize(500, 500);
            setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(photoedit.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        oldx = e.getX();
        oldy = e.getY();

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        curx = e.getX();
        cury = e.getY();
        System.out.println(curx + " : " + cury);
        System.out.println(cury -oldy);
        System.out.println(curx -oldx);
            for (int m = oldx; m < curx; m++) {
                for (int n = oldy; n < cury; n++) {
                    int pixel = img.getRGB(m, n);
                    int red = (pixel >> 16) & 0xFF;
                    int green = (pixel >> 8) & 0xFF;
                    int blue = (pixel) & 0xFF;
                    int avg = (red + blue + green) / 3;
                    red = avg;
                    green = avg;
                    blue = avg;
                    pixel = 0xFF << 24 | red << 16 | green << 8 | blue;
                    img.setRGB(m, n, pixel);

                }
            }
            repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    public void paint(Graphics g) {
        g.drawImage(img, 0, 0, this);

    }

    public static void main(String[] args) {
        new photoedit();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
//        Graphics g = getGraphics();
//         curx = e.getX();
//        cury = e.getY();
//        g.drawRect(oldx, oldy, curx-oldx, cury-oldy);
//        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

//    @Override
//    public void update(Graphics g) {
//        paint(g);
//    }
//    
    
    
    
}
