import java.awt.Frame;
class zain8 extends Frame{
 zain8(){
	System.out.println("in constructor");
	this.setSize(400,400);
	this.setVisible(true);
	}
}

class test{
public static void main (String args[]){
	zain8 obj= new zain8();
	
	}
}