class zain5{
 public static void main(String args[]){
	String pwd= "asd";
	if(pwd.equals(args[0])){
		System.out.println("welcome");
		}
	else{
		System.out.println("go");
		}
	}
}