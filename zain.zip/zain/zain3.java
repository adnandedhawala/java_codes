class zain3{
public static void main (String[] args){
 int [] x={1,3,8,9};
 System.out.println(x.length);
 for(int i=0; i<x.length; i++)System.out.println (x[i]);
 }
}