public class zain2{
}
class alpha{
}
class zk{
}
class ady1{
}