
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class MyServer {

    public MyServer() {
        try {
            ServerSocket ss = new ServerSocket(9999);
            while (true) {
                System.out.println("waiting for connection");
                Socket s = ss.accept();
                Clienthandler ch = new Clienthandler(s);

            }

        } catch (IOException ex) {
            Logger.getLogger(MyServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        new MyServer();
    }

}

class Clienthandler {

    Socket s;
    int a;
    int i = 0;

    public Clienthandler(Socket s) {
        OutputStream os;
        InputStream is;
        InputStreamReader isr;
        PrintWriter pw;
        try {
            this.s = s;
            a = s.getPort();
            System.out.println(a);
            os = s.getOutputStream();
            pw = new PrintWriter(os);
            is = s.getInputStream();
            isr = new InputStreamReader(is);
            BufferedReader br= new BufferedReader(isr);
            String str= br.readLine();
            pw.println(str);
            pw.flush();
        } catch (IOException ex) {
            Logger.getLogger(Clienthandler.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
        }

    }

}
