class xyz{
	int a=10;
}

class test{
	public static void main(String[] args) {
		xyz obj = new xyz();
		System.out.println(xyz.a);
	}
}