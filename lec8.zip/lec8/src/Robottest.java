
import com.sun.glass.ui.Cursor;
import java.awt.AWTException;
import java.awt.Frame;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class Robottest extends Frame {

    public Robottest() throws AWTException {

        Runtime rt = Runtime.getRuntime();
        try {
            rt.exec("notepad");
            
//            setSize(300, 300);
//            setVisible(true);
            Robot r = new Robot();
//            r.mouseMove(10,10);
//            r.delay(1000);
//            r.mousePress(InputEvent.BUTTON1_MASK);
//            r.delay(500);
//            r.mouseRelease(InputEvent.BUTTON1_MASK);
//            r.delay(1000);
//            r.mouseMove(10,155);
//            r.delay(500);
//            r.mousePress(InputEvent.BUTTON1_MASK);
//            r.delay(500);
//            r.mouseRelease(InputEvent.BUTTON1_MASK);
//            r.delay(500);
//            r.mouseMove(290,150);
//            r.delay(500);
//            r.mousePress(InputEvent.BUTTON1_MASK);
//            r.delay(500);
//            r.mouseRelease(InputEvent.BUTTON1_MASK);
//            r.delay(50);
//            r.keyPress(KeyEvent.VK_ENTER);
            r.delay(5000);
            r.keyPress(KeyEvent.VK_A);
            r.delay(10);
            r.keyRelease(KeyEvent.VK_A);
            r.delay(10);
            r.keyPress(KeyEvent.VK_D);
            r.delay(10);
            r.keyRelease(KeyEvent.VK_D);
            r.delay(10);
            r.keyPress(KeyEvent.VK_N);
            r.delay(10);
            r.keyRelease(KeyEvent.VK_N);
            r.delay(10);
            r.keyPress(KeyEvent.VK_A);
            r.delay(10);
            r.keyRelease(KeyEvent.VK_A);
            r.delay(10);
            r.keyPress(KeyEvent.VK_N);
            r.delay(10);
            r.keyRelease(KeyEvent.VK_N);
            
          
        } catch (IOException ex) {
            Logger.getLogger(Robottest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) throws AWTException {
        new Robottest();
    }
}
