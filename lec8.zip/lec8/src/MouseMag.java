
import java.awt.AWTException;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class MouseMag extends Frame implements Runnable {

    Rectangle rect;
    BufferedImage img;
    Robot r;

    MouseMag() {
        try {
            r = new Robot();
            setSize(200, 200);
            setVisible(true);
            Thread t = new Thread(this);
            t.start();
        } catch (AWTException ex) {
            Logger.getLogger(MouseMag.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public void paint (Graphics g){
        g.drawImage(img, 0, 0, 300, 300, this);
    }

    @Override
    public void run() {
        while(true){
            try {
                PointerInfo pi= MouseInfo.getPointerInfo();
                Point p= pi.getLocation();
                rect = new Rectangle (p.x-100,p.y-100,200,200);
                img = r.createScreenCapture(rect);
                setLocation(p.x-100,p.y+100);
                Thread.sleep(250);
                repaint();
            } catch (InterruptedException ex) {
                Logger.getLogger(MouseMag.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    public static void main(String[] args) {
        new MouseMag();
    }
}
