
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class Imge extends Frame {
    BufferedImage img;
    Imge(){
        try {
            File f = new File("C:\\lec8\\polar.jpg");
            img = ImageIO.read(f);
            setSize(350,350);
            setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(Imge.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void paint (Graphics g){
        g.drawImage(img, 10, 10, 199, 199, this);
    }
    public static void main(String[] args) {
        new Imge ();
    }
    
}
