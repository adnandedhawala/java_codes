
import java.awt.AWTException;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class Mag extends Frame{
    BufferedImage img;
    Robot r;
    Mag(){
        try {
            r= new Robot();
        } catch (AWTException ex) {
            Logger.getLogger(Mag.class.getName()).log(Level.SEVERE, null, ex);
        }
        setLocation(500,500);
        setSize(200,200);
        setVisible(true);
        Rectangle rect = new Rectangle (0,0,100,100);
        img = r.createScreenCapture(rect);
        
    }
    
    public void paint (Graphics g){
         g.drawImage(img, 0,0,200,200, this);
    }
        
    public static void main(String[] args) {
        new Mag();
    }
    
}
