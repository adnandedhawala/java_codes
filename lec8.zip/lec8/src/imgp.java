
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class imgp extends Frame implements Runnable {

    BufferedImage img;
    double tht = 0.1;
    

    imgp() {
        try {
            File f = new File("C:\\lec8\\polar.jpg");
            img = ImageIO.read(f);
            setSize(400, 400);
            setVisible(true);
            setLocation(500, 300);
            Thread t = new Thread(this);
            t.start();

        } catch (IOException ex) {
            Logger.getLogger(Imge.class.getName()).log(Level.SEVERE, null, ex);
        }

    }


    public static void main(String[] args) {
        new imgp();
    }

    @Override
    public void run() {
        Graphics2D g2 = (Graphics2D)getGraphics();
        //Double tht=Math.toRadians(90.00);
        
        while (true) {
             
            try {
                g2.drawImage(img, 150, 150, 100, 100, this);
                g2.rotate(tht, getWidth()/2, getHeight()/2);
                Thread.sleep(250);
                repaint();
            } catch (InterruptedException ex) {
                Logger.getLogger(imgp.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }

}
