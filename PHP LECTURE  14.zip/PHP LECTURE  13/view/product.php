<?php
	include_once 'header.php';

?>

	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Product Page</h2>
						<form action="../controller/product_action.php" method="POST" enctype="multipart/form-data">
							<select name="subcatid">
								<option value="">Please Select SubCategory</option>
								<?php
								$obj->get_subcategory_dropdown();	
								?>
							</select>
							<br /><br />
							<input type="text" placeholder="Mens Formals" name="product_name"/>

							<input type="text" placeholder="900" name="product_mrp"/>


							<input type="number" value="0" min="0" max="99" name="product_discount" />


							<select name="brandid">
								<option value="">Please Select Brand</option>
								<?php
								$obj->get_brand_dropdown();	
								?>
							</select>
							<br /><br />

							<input type="file" name="product_image"/>

							<textarea name="product_description"></textarea>

							<button type="submit" class="btn btn-default">Add Product</button>
						</form>
					</div><!--/login form-->
				</div>
				
				
			</div>
		</div>
	</section><!--/form-->
<?php
	include_once 'footer.php';

?>