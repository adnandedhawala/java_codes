<?php
	
	session_start();


	// unset delete all variables.
	unset($_SESSION['useremailid']);
	unset($_SESSION['usernamedata']);

	session_destroy();
	header("location:login.php");

?>