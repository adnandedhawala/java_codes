<?php
	include_once 'header.php';

?>

	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Subcategory Page</h2>
						<form action="../controller/subcategory_action.php " method="POST">
							<select name="catid">
								<option value="">Please Select Category</option>
								<?php
								$obj->get_category_dropdown();	
								?>
							</select>
							<br /><br />
							<input type="text" placeholder="Mens Formals" name="subcatname"/>
							<button type="submit" class="btn btn-default">Add Subcategory</button>
						</form>
					</div><!--/login form-->
				</div>
				
				
			</div>
		</div>
	</section><!--/form-->
<?php
	include_once 'footer.php';

?>