<?php
//https://trinitytuts.com/payumoney-payment-gateway-integration-in-php/
	include 'header.php';
// 	echo "<pre>";
// 	print_r($_POST);
// 	echo "</pre>"; 

// // exit;
	$mobileno = $_SESSION['usermobile'];

	$amt = $_POST['amount'];
	$id = $_POST['txnid'];
	$msg = "Hi Your payment done.Amount is:$amt ,txn_id :$id";
	$message = urlencode($msg);
	$path = "http://login.redsms.in/API/SendMessage.ashx?user=prashantkadam&password=prashant@123&phone=$mobileno&text=$message&type=t&senderid=INFORM";
		//echo $path;
	 	$result = file($path);


	echo "<pre>";
	print_r($result);

	mysqli_query($obj->conn,"insert into transaction (	txnid,mobileno,	amount) values ('$id','$mobileno','$amt') ") or die(mysqli_error($obj->conn));
?>

<?php
	include 'footer.php';
?>