<?php
	include_once 'header.php';

?>

	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
						<form action="../controller/login_action.php " method="POST">
							<input type="text" placeholder="Email Address" name="useremail"/>
							<input type="password" placeholder="Password" name="userpass"/>
							<button type="submit" class="btn btn-default">Login</button>
						</form>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
						<form action="../controller/register_action.php " method="POST">
							<input type="text" placeholder="Name" name="username"/>
							<input type="text" placeholder="Mobile" name="usermobile"/>
							<input type="text" placeholder="Email Address" name="useremail"/>
							<input type="password" placeholder="Password" name="userpass"/>
							<input type="password" placeholder="Confirm Password" name="usercpass"/>
							<button type="submit" class="btn btn-default">Signup</button>
						</form>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
<?php
	include_once 'footer.php';

?>