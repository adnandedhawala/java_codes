<script>
// window.location.href="view/index.php";
</script>

<?php
	header("location:view/index.php");
?>