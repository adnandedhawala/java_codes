$(document).ready(function(){
	// alert();
	//register
	$(".reg_btn").click(function(){
		var rec = $("#reg_form").serialize();
		// alert(rec);
		$.post("../controller/register_action.php",rec).success(function(response){
			$(".reg_err").html(response);
		});
	});

	//login
	$(".log_btn").click(function(){
		var rec = $("#login_form").serialize();
		// alert(rec);
		$.post("../controller/login_action.php",rec).success(function(response){
			if(response == 1){
				window.location.href = "index.php";
			}
			else{
				$(".log_err").html(response);	
			}
		});
	});
});