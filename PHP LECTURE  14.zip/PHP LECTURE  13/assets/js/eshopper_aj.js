app = angular.module("eshopper",[]);

app.controller("eshopper_controller", function($scope, $http){

	/*wishlist*/
	$scope.add_wishlist = function(pid){

	$http.post("../controller/wishlist_action.php",{proid:pid}).success(function(response){

		alert(response);
	})

	}

	$scope.delete_wishlist = function(pid){

	$http.post("../controller/delete_wishlist_action.php",{proid:pid}).success(function(response){

		alert(response);
		window.location.href="wishlist.php";
	})

	}

	/*wishlist*/

});