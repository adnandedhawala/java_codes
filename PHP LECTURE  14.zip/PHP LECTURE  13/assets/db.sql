create database shravan;

	create table login(

			log_id int auto_increment primary key,
			log_name varchar(100),
			log_mobile bigint,
			log_email varchar(100),
			log_pass varchar(100)


		);


	create table category(
ca_id int auto_increment primary key,
ca_name varchar(100)
);


	create table brand(

		br_id int auto_increment primary key,
		br_name varchar(100)

		);

	create table subcategory(

		sub_id int auto_increment primary key,
		sub_name varchar(100),
		sub_cid int
		);

	create table product
	(
		pro_id int auto_increment primary key,
		pro_name varchar(100),
		pro_mrp decimal(8,2),
		pro_discount tinyint,
		pro_description longtext,
		pro_subid int,
		pro_brid int,
		pro_imgpath text

	);