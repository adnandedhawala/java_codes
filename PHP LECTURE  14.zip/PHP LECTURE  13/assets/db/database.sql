create database aalam;

create table login(
	log_id int auto_increment primary key,
	log_name varchar(100),
	log_email varchar(100),
	log_pass varchar(100),
	log_mobile bigint,
	log_time timestamp
);