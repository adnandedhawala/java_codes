-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2016 at 10:32 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shravan`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `br_id` int(11) NOT NULL AUTO_INCREMENT,
  `br_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`br_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`br_id`, `br_name`) VALUES
(9, 'Nike'),
(10, 'Puma'),
(13, 'Ray Ban'),
(16, 'Allen Solly');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `ca_id` int(11) NOT NULL AUTO_INCREMENT,
  `ca_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ca_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ca_id`, `ca_name`) VALUES
(15, 'Mens Wear'),
(16, 'Womens Wear'),
(17, 'Accessories');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_name` varchar(100) DEFAULT NULL,
  `log_mobile` bigint(20) DEFAULT NULL,
  `log_email` varchar(100) DEFAULT NULL,
  `log_pass` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`log_id`, `log_name`, `log_mobile`, `log_email`, `log_pass`) VALUES
(1, 'akky', 8798798799, 'akky@gmail.com', '76af7efae0d034d1e3335ed1b90f24b6cadf2bf1'),
(2, 'adnan', 9809809800, 'adnan@gmil.com', '76af7efae0d034d1e3335ed1b90f24b6cadf2bf1'),
(3, 'Shravan Ajmera', 9867479719, 'shravan.ajmera@gmail.com', '49049515566fa38e1b8e268723a3730dcf527f36');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `mobile` int(11) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`userid`, `username`, `mobile`) VALUES
(4, 'adnan', 980),
(5, 'adnan1', 9801),
(6, 'adnan2', 9803);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(100) DEFAULT NULL,
  `pro_mrp` decimal(8,2) DEFAULT NULL,
  `pro_discount` tinyint(4) DEFAULT NULL,
  `pro_description` longtext,
  `pro_subid` int(11) DEFAULT NULL,
  `pro_brid` int(11) DEFAULT NULL,
  `pro_imgpath` text,
  PRIMARY KEY (`pro_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pro_id`, `pro_name`, `pro_mrp`, `pro_discount`, `pro_description`, `pro_subid`, `pro_brid`, `pro_imgpath`) VALUES
(1, 'Mens Selvestor Printed Shirt', 2300.00, 20, 'Add one more style to your fab collection with this shirt from Yepme. Striped pattern on the yoke, sleeves and pocket, it is an enticing choice to look handsome. Wear it with a pair of pants and sneakers for a striking look', 29, 16, '../assets/uploads/147841848015432016-11-06-08-48-00158487_ypxl_1.jpg'),
(2, 'Yepme Albert Solid Shirt white', 7800.00, 80, 'Add one more style to your fab collection with this shirt from Yepme. Striped pattern on the yoke, sleeves and pocket, it is an enticing choice to look handsome. Wear it with a pair of pants and sneakers for a striking look', 29, 9, '../assets/uploads/147841853496132016-11-06-08-48-54158501_ypxl_1.jpg'),
(3, 'Yepme Stefan Striped Shirt', 2900.00, 10, 'Add one more style to your fab collection with this shirt from Yepme. Striped pattern on the yoke, sleeves and pocket, it is an enticing choice to look handsome. Wear it with a pair of pants and sneakers for a striking look', 29, 10, '../assets/uploads/147841856992152016-11-06-08-49-29167413_ypxl_1.jpg'),
(4, 'Yepme Drake Formal Shirt grey and white', 3200.00, 10, 'To get a noticeable look at work, you must make a wise choice while selecting your attire. This smart and sober shirt by Yepme can be a great choice for projecting the decent you. ', 28, 16, '../assets/uploads/147841869272382016-11-06-08-51-3261537_ypxl_1.jpg'),
(5, 'Yepme Bevis Formal Shirt', 7600.00, 20, 'To get a noticeable look at work, you must make a wise choice while selecting your attire. This smart and sober shirt by Yepme can be a great choice for projecting the decent you.', 28, 9, '../assets/uploads/147841875169762016-11-06-08-52-3161542_ypxl_1.jpg'),
(6, 'Yepme Trisha Party Top', 3900.00, 90, 'Drape your beauty in this adorable creation!\r\n\r\nCrafted in flattering fit and imbued with contemporary style appeal, it is an ideal piece to go for a club party.', 30, 10, '../assets/uploads/147841882855132016-11-06-08-53-48139427_ypxl_1.jpg'),
(7, 'Yepme Trisha Party Top Black', 3100.00, 32, 'To get a noticeable look at work, you must make a wise choice while selecting your attire. This smart and sober shirt by Yepme can be a great choice for projecting the decent you. ', 30, 10, '../assets/uploads/147841886858072016-11-06-08-54-28139428_ypxl_1.jpg'),
(8, 'Vibrant Orange Magenta And Beige', 12000.00, 80, 'To get a noticeable look at work, you must make a wise choice while selecting your attire. This smart and sober shirt by Yepme can be a great choice for projecting the decent you. ', 31, 16, '../assets/uploads/147841898790912016-11-06-08-56-27166674_ypxl_1.jpg'),
(9, 'Vibrant Blue red And Beige', 8900.00, 30, 'To get a noticeable look at work, you must make a wise choice while selecting your attire. This smart and sober shirt by Yepme can be a great choice for projecting the decent you. ', 31, 9, '../assets/uploads/147841901580722016-11-06-08-56-55166675_ypxl_1.jpg'),
(10, 'epme Mens Dual Movement Watch', 2400.00, 40, 'Add one more style to your fab collection with this shirt from Yepme. Striped pattern on the yoke, sleeves and pocket, it is an enticing choice to look handsome. Wear it with a pair of pants and sneakers for a striking look', 32, 9, '../assets/uploads/147841912092732016-11-06-08-58-40watch_ypxl_1.jpg'),
(11, 'Yepme Mens Traditional  Watch', 4000.00, 60, 'Add one more style to your fab collection with this shirt from Yepme. Striped pattern on the yoke, sleeves and pocket, it is an enticing choice to look handsome. Wear it with a pair of pants and sneakers for a striking look', 32, 16, '../assets/uploads/147841916314582016-11-06-08-59-23watch_ypxl_2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(50) DEFAULT NULL,
  `sub_cid` int(11) DEFAULT NULL,
  `sub_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`sub_id`, `sub_name`, `sub_cid`, `sub_time`) VALUES
(28, 'Mens formal', 15, '2016-11-06 07:43:33'),
(29, 'Mens Casual Wear', 15, '2016-11-06 07:43:42'),
(30, 'Women Casual Wear', 16, '2016-11-06 07:43:54'),
(31, 'Women Sarees', 16, '2016-11-06 07:44:03'),
(32, 'Watches', 17, '2016-11-06 07:44:26'),
(33, 'Wallets', 17, '2016-11-06 07:44:36');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE IF NOT EXISTS `wishlist` (
  `wi_id` int(11) NOT NULL AUTO_INCREMENT,
  `wi_uid` int(11) NOT NULL,
  `wi_pid` int(11) NOT NULL,
  `wi_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`wi_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wi_id`, `wi_uid`, `wi_pid`, `wi_time`) VALUES
(1, 3, 1, '2016-12-04 08:26:01'),
(2, 3, 3, '2016-12-04 08:26:05');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
