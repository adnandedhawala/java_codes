<?php

session_start();
// echo session_id();
include_once '../model/db_project.php';

//echo "<pre>";
//print_r($_POST);

echo "<pre>";
print_r($_POST);

if(empty($_POST['catid']))

{
	echo "Please Select Category";
}

else
{
	$reg="/^[a-zA-Z][a-zA-Z ]{1,}[a-zA-Z]$/";

	if(preg_match($reg,$_POST['subcatname']) !=1)
	{
		echo "Invalid Subcategory Name";
	}

	else
	{
		$subname=$_POST['subcatname'];
		$cid=$_POST['catid'];
		$str = "insert into subcategory (sub_name, sub_cid) values ('$subname','$cid')";

		$result = mysqli_query($obj->conn, $str) or die (mysqli_error($obj->conn));

		//var_dump($result);

		echo "Record Added";
	}
}

?>