<?php
	include_once '../model/db_project.php';

	echo "<pre>";
	print_r($_POST);

	echo "<pre>";
	print_r($_FILES);

	$reg_pro = "/^[a-zA-Z0-9][a-zA-Z0-9_\.\- ]{1,}[a-zA-Z0-9]$/";
	if(empty($_POST['subcatid']))
	{
		echo "Please Select SubCategory";
	}
	else if( preg_match($reg_pro , $_POST['product_name'])!=1 )
	{
		echo "Invalid Product Name";
	}
	else if(!is_numeric($_POST['product_mrp']) || $_POST['product_mrp']<0)
	{
		echo "Invalid MRP";
	}
	else if(!ctype_digit($_POST['product_discount']) || $_POST['product_discount']<0 || $_POST['product_discount']>99)
	{
		echo "Invalid Discount";
	}
	else if(empty($_POST['brandid']))
	{
		echo "Plz select Brand";
	}
	else if( strlen($_POST['product_description']) < 10 || strlen($_POST['product_description']) > 2000 )
	{
		echo "Invalid Description Length";
	}
	else{
		// echo 1;
		if(empty($_FILES['product_image']['name']))
		{
			echo "please select Image";
		}
		else if($_FILES['product_image']['type']!="image/jpeg" && $_FILES['product_image']['type']!="image/gif" && $_FILES['product_image']['type']!="image/png")
		{
			echo "Invalid Image Selected";
		}
		else if($_FILES['product_image']['size'] > 1*1024*1024)
		{
			echo "File size large";
		}
		else{
			$name = str_replace(" ","_",$_FILES['product_image']['name']);
			$buff = $_FILES['product_image']['tmp_name'];

			$path = "../assets/uploads/".time().rand(1000,9999).date('Y-m-d-H-i-s').$name;

			// echo $path;
			$result = move_uploaded_file($buff, $path);

			// var_dump($result);

			if($result==1)
			{
				$subid = $_POST['subcatid'];
				$pname = $_POST['product_name'];
				$mrp = $_POST['product_mrp'];
				$discount = $_POST['product_discount'];
				$desc = $_POST['product_description'];
				$brid = $_POST['brandid'];

				$str = "insert into product (pro_name,pro_mrp,pro_discount,pro_description,pro_subid,pro_brid,pro_imgpath) values ('$pname','$mrp','$discount','$desc','$subid','$brid','$path')";
				$result=mysqli_query($obj->conn, $str) or die (mysqli_error($obj->conn));

				//var_dump($result);

				echo "Record Added";
			}
		}
	}
?>