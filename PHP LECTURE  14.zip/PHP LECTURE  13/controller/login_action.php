<?php

session_start();
// echo session_id();
include_once '../model/db_project.php';

//echo "<pre>";
//print_r($_POST);


	$reg_email = "/^([a-z0-9][a-z0-9\._]{1,}[a-z0-9])@([a-z0-9][a-z0-9\-]{1,}[a-z0-9])\.([a-z]{2,})(\.[a-z]{2,})?$/";
		$res_email = preg_match($reg_email, $_POST['useremail']);

if ($res_email!=1)
{

	echo "Invalid EmailID";
}

else
{
	$reg_pass= "/^[a-z0-9A-Z]{4,12}$/";
	$res_pass= preg_match($reg_pass, $_POST['userpass']);

	if($res_pass!=1)
	{
		echo "Invalid Password";
	}

	else
	{
		//echo "ok";
		$email = $_POST['useremail'];
		$pass = sha1($_POST['userpass']);

		$sql = "select log_name, log_pass, log_id,log_mobile from login where log_email='$email'";

		//echo $sql;

		$result = mysqli_query($obj->conn, $sql) or die (mysqli_error($obj->conn));

		//print_r($result);

		if($result->num_rows==0)
		{
			echo "EmailID Does Not Exist";
		}

		else
		{
			$ans = $result->fetch_array(MYSQL_ASSOC);

			//print_r($ans);

			if ($ans['log_pass']==$pass)
			{
				//echo "ok";

				$_SESSION['useremailid']=$email;
				$_SESSION['usernamedata']=$ans['log_name'];
				$_SESSION['userid']=$ans['log_id'];
				$_SESSION['usermobile']=$ans['log_mobile'];
				// print_r($_SESSION);
				header("location:../view/index.php");
			}

			else
			{
				echo "Password Does Not Match";
			}
		}
	}
}

?>