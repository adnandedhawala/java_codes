<?php

	session_start();
	include '../model/db_project.php';
	$ans = (array) json_decode(file_get_contents("php://input"));
	//print_r($ans);
	$pid = $ans['proid'];
	//echo $pid;
    
    $uid = $_SESSION['userid'];

    $str = "delete from wishlist where wi_uid='$uid' and wi_pid='$pid'";
    $result = mysqli_query($obj->conn, $str) or die (mysqli_error($obj->conn));

    //var_dump($result);

    echo "Product Deleted";


?>