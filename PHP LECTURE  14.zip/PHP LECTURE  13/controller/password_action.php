<?php

session_start();
// echo session_id();
include_once '../model/db_project.php';

//echo "<pre>";
//print_r($_POST);

$reg_pass="/^[a-z0-9A-Z]{4,12}$/";
$res_pass=preg_match($reg_pass, $_POST['oldpass']);
$res_npass=preg_match($reg_pass,$_POST['newpass']);
if($res_pass!=1)
{
	echo "Invalid Current Password";
}

else if($res_npass!=1)
{
	echo "Invalid New Password";
}

else if($_POST['newpass']!=$_POST['cnewpass'])
{
	echo "New Pass Should Be Different From Current Password";
}

else
{
	$email = $_SESSION['useremailid'];
	//echo $email;
	$str="select log_pass from login where log_email='$email'";
	$result=mysqli_query($obj->conn, $str) or die (mysqli_error($obj->conn));

	$ans=$result->fetch_array(MYSQL_ASSOC);
	print_r($ans);

	if($ans['log_pass']!=sha1($_POST['oldpass']))
	{
		echo "Current Password Mismatch";
	}

	else
	{
		//echo "ok";
		$newpass=sha1($_POST['newpass']);
		//echo $newpass;

		$sql="update login set log_pass='$newpass'where log_email='$email'";
		//echo $sql;

		$result=mysqli_query($obj->conn, $sql) or die (mysqli_error($obj->conn));

		echo "Password Updated";
	}
}

?>