<?php

	session_start();
	include '../model/db_project.php';
	$ans = (array) json_decode(file_get_contents("php://input"));
	//print_r($ans);
	$pid = $ans['proid'];
	//echo $pid;

	if( isset($_SESSION['useremailid']) ){

		//echo 1;
		$uid = $_SESSION['userid'];
		//echo $uid;

		$sql = "select count(*) as cnt from  wishlist where wi_uid='$uid' and wi_pid='$pid'";

		//echo $sql;
		$result = mysqli_query($obj->conn, $sql) or die(mysqli_error($obj->conn));

		$ans = $result->fetch_array(MYSQL_ASSOC);
		//print_r($ans);
		//exit;

		if($ans['cnt']==1)
		{
			echo "Record Exists";
		}
		else
		{
			$str = "insert into wishlist (wi_uid, wi_pid) values ('$uid','$pid')";
			$result = mysqli_query($obj->conn, $str) or die (mysqli_error($obj->conn));

			//var_dump($result);
			echo "Record Added";
		}

	}
	else
	{
		echo "Please Do Login To Add Record In Wishlist";
	}


?>