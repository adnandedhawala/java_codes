<?php

session_start();
// echo session_id();
include_once '../model/db_project.php';

//echo "<pre>";
//print_r($_POST);
$reg_email ="/^[a-zA-Z0-9][a-z0-9A-Z ]{1,}[a-z0-9A-Z]$/";
$res_email = preg_match($reg_email, $_POST['brandname']);
if($res_email!=1)

{
	echo "Invalid Brand";
}

else
{
	$data = $_POST['brandname'];
	//echo $data;
	$sql = "select count(*) as cnt from brand where br_name='$data'";
	//echo $sql;
	$result = mysqli_query($obj->conn, $sql) or die(mysqli_error($obj->conn));

	$ans = $result->fetch_array(MYSQL_ASSOC);
	//print_r($ans);

	//exit();

	if($ans['cnt']==1)
	{
		echo "Brand Exist";
	}

	else
	{
		$str = "insert into brand (br_name) values ('$data')";
		$result=mysqli_query($obj->conn, $str) or die (mysqli_error($obj->conn));

		//var_dump($result);

		echo "Record Added";
	}
}


?>