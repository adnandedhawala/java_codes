<?php

include_once '../model/db_project.php';

//echo "<pre>";
//print_r($_POST);


//exp for name
//yogesh patil

// Storing Regular Express Validation Into $reg_name Variable.
$reg_name = "/^[a-zA-Z][a-zA-Z ]{1,}[a-zA-Z]$/";
$res_name = preg_match($reg_name, $_POST['username']);

//echo $res_name

if($res_name!=1)
{
	echo "Invalid Name";
}
else
{
	$reg_mob = "/^[1-9][0-9]{9}$/";
	$res_mob = preg_match($reg_mob, $_POST['usermobile']);

	if($res_mob!=1)
	{
		echo "Invalid Mobile";
	}
	else
	{
		//yogesh.patil@gmail.com
		// (yogesh.patil_123)@(gmail).(co).(.in)?

		$reg_email = "/^([a-z0-9][a-z0-9\._]{1,}[a-z0-9])@([a-z0-9][a-z0-9\-]{1,}[a-z0-9])\.([a-z]{2,})(\.[a-z]{2,})?$/";
		$res_email = preg_match($reg_email, $_POST['useremail']);

		if($res_email!=1)
		{
			echo "Invalid EmailID";
		}

		else
		{
			$reg_pass = "/^[a-z0-9A-Z]{4,12}$/";
			$res_pass = preg_match($reg_pass, $_POST['userpass']);

			if($res_pass!=1)
			{
				echo "Invalid Password";
			}

			else if($_POST['userpass']!=$_POST['usercpass'])
			{
				echo "Password Does Not Match";
			}
			else
			{
				//echo 1;

				$name = $_POST['username'];
				$mob = $_POST['usermobile'];
				$email = $_POST['useremail'];
				$pass = sha1($_POST['userpass']);

				// echo $pass;

				$sql= "select count(*) as cnt from login where log_email='$email'";

				// echo $sql;

				$result = mysqli_query($obj->conn, $sql) or die (mysqli_error($obj->conn));

				$ans = $result->fetch_array(MYSQL_ASSOC);

				//print_r($ans);
				// exit();

				if($ans['cnt']==1){

					echo 'Email Already Exist';
				}
				else
				{
					//query prepare

				$str = "insert into login(log_name,log_mobile,log_email,log_pass) values ('$name','$mob','$email','$pass')";

				// echo $str;

				// print_r($obj->conn);


				$result = mysqli_query($obj->conn,$str) or die(mysqli_error($obj->conn));

				//var_dump($result);

				echo "Record Added";	

				}



						
			}
			{

			}
		}
	}
}

?>