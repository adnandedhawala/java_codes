<?php
	include_once 'db_connect.php';

	abstract class helper extends connect{

	}
?>