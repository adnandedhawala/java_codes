<?php
	interface connection{
		
		// giving connection structure.
		
		const HOST = "localhost";
		const USER = "root";
		const PASS = "";
		const DB="adnan23626";
	}
?>