<?php
	include_once("db_parameter.php");

	abstract class connect implements connection{
		var $conn="";
		function __construct(){
			
			$this->conn = mysqli_connect(

				// starting connection.

				connection::HOST,connection::USER,connection::PASS,connection::DB

			);

			//echo "<pre>";
			//print_r($this->conn);

		}
		function __destruct(){
			
			//closing connection. 

			$result = mysqli_close($this->conn);
			//var_dump($result);
		}
	}
?>