<?php
	include_once 'db_helper.php';

	final class project extends helper{

		function get_brands()
		{
			$str = "select br_id, br_name from brand order by br_name asc";
			$rows = mysqli_query($this->conn, $str) or die (mysqli_error($this->conn));

			//echo "<pre>";
			//print_r($rows);

			if ($rows->num_rows > 0)
			{
				while($result = $rows->fetch_array(MYSQL_ASSOC))

				{
					//echo "<pre>"
					// print_r($result);

					$brname = $result['br_name'];
					$brid = $result ['br_id'];

					echo "<li><a href='brandwise_product.php?id=$brid'><span class='pull-right'>(50)</span>$brname</a></li>";
				}
			}
		}


		function get_category()
		{
			$str = "select ca_id, ca_name from category order by ca_name asc";
			$rows = mysqli_query($this->conn, $str) or die (mysqli_error($this->conn));

			//echo "<pre>";
			//print_r($rows);

			if ($rows->num_rows > 0)
			{
				while($result = $rows->fetch_array(MYSQL_ASSOC))

				{
					//echo "<pre>"
					// print_r($result);

					$caname = $result['ca_name'];
					$catid = $result ['ca_id'];

					echo"<div class='panel-heading'><h4 class='panel-title'><a href='catwise_product.php?id=$catid'>$caname</a></h4></div>";
				}
			}
		}

		function get_category_dropdown()
		{
			$str = "select ca_id, ca_name from category order by ca_name asc";
			$rows = mysqli_query($this->conn, $str) or die (mysqli_error($this->conn));

			//echo "<pre>";
			//print_r($rows);

			if ($rows->num_rows > 0)
			{
				while($result = $rows->fetch_array(MYSQL_ASSOC))

				{
					//echo "<pre>"
					// print_r($result);

					$caname = $result['ca_name'];
					$catid = $result ['ca_id'];

					echo"<option value='$catid'>$caname</option>";
				}
			}
		}

		function get_subcategory_dropdown()
		{
			$str = "select sub_id, sub_name from subcategory order by sub_name asc";
			$rows = mysqli_query($this->conn, $str) or die (mysqli_error($this->conn));
			if ($rows->num_rows > 0)
			{
				while($result = $rows->fetch_array(MYSQL_ASSOC))

				{
					$caname = $result['sub_name'];
					$catid = $result ['sub_id'];
					echo"<option value='$catid'>$caname</option>";
				}
			}
		}

		function get_brand_dropdown()
		{
			$str = "select br_id,br_name from brand order by br_name asc";
			$rows = mysqli_query($this->conn, $str) or die (mysqli_error($this->conn));

			//echo "<pre>";
			//print_r($rows);

			if ($rows->num_rows > 0)
			{
				while($result = $rows->fetch_array(MYSQL_ASSOC))

				{
					//echo "<pre>"
					// print_r($result);

					$caname = $result['br_name'];
					$catid = $result ['br_id'];

					echo"<option value='$catid'>$caname</option>";
				}
			}
		}


			function get_all_products()
			{
				$sql="select br_id,br_name,ca_id,ca_name, sub_id, sub_name,pro_id,pro_name,pro_mrp,pro_discount,pro_description,pro_imgpath from category,brand,subcategory,product where br_id=pro_brid and sub_id=pro_subid and ca_id=sub_cid";

				$rows = mysqli_query($this->conn, $sql) or die (mysqli_error($this->conn));

				if($rows->num_rows > 0)
				{
					while($result = $rows->fetch_array(MYSQL_ASSOC))

					{
						//echo "<pre>";
						// print_r($result);
						$finalans[]=$result;
					}

					// echo "<pre>";
					// print_r($finalans);
					return $finalans;
				}

			}


			function get_wishlist_products()
			{
				$uid = $_SESSION['userid'];
				$sql="select br_id,br_name,ca_id,ca_name, sub_id, sub_name,pro_id,pro_name,pro_mrp,pro_discount,pro_description,pro_imgpath from category,brand,subcategory,product,wishlist where br_id=pro_brid and sub_id=pro_subid and ca_id=sub_cid and wi_pid=pro_id and wi_uid='$uid'";

				$rows = mysqli_query($this->conn, $sql) or die (mysqli_error($this->conn));

				if($rows->num_rows > 0)
				{
					while($result = $rows->fetch_array(MYSQL_ASSOC))

					{
						//echo "<pre>";
						// print_r($result);
						$finalans[]=$result;
					}

					// echo "<pre>";
					// print_r($finalans);
					return $finalans;
				}

			}

			function get_cat_wise_products($xyz)
			{
				$sql="select br_id,br_name,ca_id,ca_name, sub_id, sub_name,pro_id,pro_name,pro_mrp,pro_discount,pro_description,pro_imgpath from category,brand,subcategory,product where br_id=pro_brid and sub_id=pro_subid and ca_id=sub_cid and ca_id='$xyz'";

				$rows = mysqli_query($this->conn, $sql) or die (mysqli_error($this->conn));

				if($rows->num_rows > 0)
				{
					while($result = $rows->fetch_array(MYSQL_ASSOC))

					{
						//echo "<pre>";
						// print_r($result);
						$finalans[]=$result;
					}

					// echo "<pre>";
					// print_r($finalans);
					return $finalans;
				}

			}

			function get_brandwise_products($xyz)
			{
				$sql="select br_id,br_name,ca_id,ca_name, sub_id, sub_name,pro_id,pro_name,pro_mrp,pro_discount,pro_description,pro_imgpath from category,brand,subcategory,product where br_id=pro_brid and sub_id=pro_subid and ca_id=sub_cid and br_id='$xyz'";

				$rows = mysqli_query($this->conn, $sql) or die (mysqli_error($this->conn));

				if($rows->num_rows > 0)
				{
					while($result = $rows->fetch_array(MYSQL_ASSOC))

					{
						//echo "<pre>";
						// print_r($result);
						$finalans[]=$result;
					}

					// echo "<pre>";
					// print_r($finalans);
					return $finalans;
				}

			}



}

	$obj = new project();
?>