<?php
	//https://control.textlocal.in/docs/api/code/post/

	// http://login.redsms.in/Users/SendSMS.aspx
?>

<?php
	// Authorisation details.
	$username = "abskdm1197@gmail.com";
	$hash = "02d15c4a562f3cd8ae861e68f040b7af55f46881";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "919867971640"; // A single number or a comma-seperated list of numbers
	$message = "HELLO YOGESH HOW R U?";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);

	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;

	$path = 'http://api.textlocal.in/send/?'.$data;

	$result = file($path);

	echo "<pre>";
	print_r($result);

?>	