
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class ImageServer extends Frame implements Runnable {

    InputStream is;
    BufferedImage img;

  public  ImageServer() {

        try {
            ServerSocket ss = new ServerSocket(9999);
            System.out.println("Waiting for connection");
            Socket s = ss.accept();
            System.out.println("connected");
            is = s.getInputStream();  
            setSize(300, 300);
            setVisible(true);
            setLocation(500, 500);
                      
            Thread t = new Thread(this);
            t.start();
        } catch (IOException ex) {
            Logger.getLogger(ImageServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

  public void update(Graphics g){
      paint(g);
  }
   

    @Override
    public void run() {
        while (true) {
            try {
                img = ImageIO.read(is);
                System.out.println(img);
                repaint();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ImageServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (IOException ex) {
                Logger.getLogger(ImageServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
     public void paint(Graphics g) {
       if (img != null)
        {
            g.drawImage(img, 0, 0, this);
        }

    }

    public static void main(String[] args) {
        new ImageServer();
    }

}
