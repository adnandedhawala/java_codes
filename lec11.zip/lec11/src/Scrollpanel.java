
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.Scrollbar;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class Scrollpanel extends Frame implements AdjustmentListener {

    Scrollbar sb_red, sb_blue, sb_green;

    Scrollpanel() {
        Panel p = new Panel();
        p.setLayout(new GridLayout(3, 1));
        sb_red = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 265);
        sb_blue = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 265);
        sb_green = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 265);
        p.add(sb_red);
        p.add(sb_blue);
        p.add(sb_green);
        add(p, BorderLayout.SOUTH);
        setSize(300, 300);
        setVisible(true);
        sb_red.addAdjustmentListener(this);
        sb_blue.addAdjustmentListener(this);
        sb_green.addAdjustmentListener(this);

    }

    @Override
    public void adjustmentValueChanged(AdjustmentEvent e) {
        int red = sb_red.getValue();
        int blue = sb_blue.getValue();
        int green = sb_green.getValue();
        
        Color c= new Color(red,green,blue);
        setBackground(c);

    }
    public static void main(String[] args) {
        new Scrollpanel ();
    }
}
