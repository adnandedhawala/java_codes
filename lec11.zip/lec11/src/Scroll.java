
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Scrollbar;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import javafx.scene.control.ScrollBar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class Scroll extends Frame implements AdjustmentListener {

    Scrollbar sb;

    Scroll() {
        sb = new Scrollbar(Scrollbar.HORIZONTAL, 50, 10, 0, 100);
        add(sb, BorderLayout.SOUTH);
        sb.addAdjustmentListener(this);
        setSize(300, 300);
        setVisible(true);

    }

    @Override
    public void adjustmentValueChanged(AdjustmentEvent e) {
        int val = sb.getValue();
        System.out.println(val);
    }

    public static void main(String[] args) {
        new Scroll();
    }

}
