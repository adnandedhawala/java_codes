
import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class ImageClient extends Thread {

    OutputStream os;
    BufferedImage img;
    Rectangle rect;

    Robot r;

    ImageClient() {
        try {
            try {
                r = new Robot();
            } catch (AWTException ex) {
                Logger.getLogger(ImageClient.class.getName()).log(Level.SEVERE, null, ex);
            }
            Socket s = new Socket("localhost", 9999);
            os = s.getOutputStream();

            start();

        } catch (IOException ex) {
            Logger.getLogger(ImageClient.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void run() {

     
        while (true) {
            try {
                rect = new Rectangle(0, 0, 100, 100);
                img = r.createScreenCapture(rect);
                ImageIO.write(img, "jpg", os);
                
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ImageClient.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } catch (IOException ex) {
                Logger.getLogger(ImageClient.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    public static void main(String[] args) {
        new ImageClient();
    }
}
