
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class SlideImage extends Frame implements MouseListener, KeyListener {

    int index, oldx, x, i, key, dx;
    BufferedImage img[];

    SlideImage() {
        img = new BufferedImage[5];
        for (i = 0; i < 5; i++) {
            try {
                File f = new File("C:\\lec10nb\\image" + (i + 1) + ".jpg");
                img[i] = ImageIO.read(f);

            } catch (IOException ex) {
                Logger.getLogger(SlideImage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        addMouseListener(this);
        addKeyListener(this);
        setSize(300, 300);
        setVisible(true);
    }

    public void paint(Graphics g) {
        g.drawImage(img[index], 0, 0, 200, 200, this);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        oldx = e.getX();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        x = e.getX();
        dx = x - oldx;
        if (Math.abs(dx) > 100) {
            if (dx < 0) {
                index--;
                if (index < 0) {
                    index = img.length - 1;
                    System.out.println("left");
                    System.out.println(index);
                }

            } else {
                index++;
                if (index >= img.length) {
                    index = 0;
                    System.out.println("right");
                    System.out.println(index);
                }
            }
        }

        repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    public static void main(String[] args) {
        new SlideImage();
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            index--;
            if (index < 0) {
                index = img.length - 1;
                System.out.println("left");
                System.out.println(index);
            }

        }

        if (key == KeyEvent.VK_RIGHT) {
            index++;
            if (index >= img.length) {
                index = 0;
                System.out.println("right");
                System.out.println(index);
            }
        }
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

}
