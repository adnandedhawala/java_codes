
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class Client extends Frame implements MouseListener, MouseMotionListener {
DatagramSocket ds;
int oldx , oldy;
    public Client ()
            {
                try {
        ds = new DatagramSocket();
                
                } catch (SocketException ex) {
        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
    }
        addMouseListener(this);
        addMouseMotionListener(this);
        setSize(300,300);
        setVisible (true);
        setTitle ("CLIENT");
    
        
    }
    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        oldx = e.getX();
        oldy = e.getY();
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    try {
        Graphics g = getGraphics();
        int x= e.getX();
        int y= e.getY();
        
        byte [] buf = new byte [512];
        String str = x+ "," +y + ","+ oldx+","+oldy;
        System.out.println(str);
        buf = str.getBytes();
        g.drawLine (oldx, oldy, x, y);
        oldx = x;
        oldy = y;
        
        
        
        DatagramPacket dp = new DatagramPacket(buf, buf.length, InetAddress.getLocalHost(),9999);
        ds.send(dp);
    } catch (IOException ex) {
        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
    }
        
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }
    
    public static void main(String[] args) {
        new Client ();
    }
}

