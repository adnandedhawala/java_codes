
import java.awt.Frame;
import java.awt.Graphics;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class Server extends Frame implements Runnable {

    DatagramSocket ds;
    int oldx, oldy;

    public Server() {
        try {
            
            ds = new DatagramSocket(9999);
            setSize(300, 300);
            setVisible(true);
            setTitle("SERVER");
            Thread t = new Thread(this);
            t.start();
        } catch (SocketException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void run() {
        Graphics g = getGraphics();
        while (true) {
            try {

                byte[] buf = new byte[512];
                DatagramPacket dp = new DatagramPacket(buf, buf.length);
                ds.receive(dp);
                buf = dp.getData();
                String str = new String(buf);
                str = str.trim();
                System.out.println(str);
                String[] toks = str.split(",");
                int x = Integer.parseInt(toks[0]);
                int y = Integer.parseInt(toks[1]);
                oldx = Integer.parseInt(toks[2]);
                oldy = Integer.parseInt(toks[3]);
                g.drawLine(oldx, oldy, x,y);

            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public static void main(String[] args) {
        new Server();
    }

}
