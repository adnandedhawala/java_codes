
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lenovo
 */
public class direction extends Frame implements MouseListener, MouseMotionListener {

    int x1, x2,y1,y2;

    public direction() throws HeadlessException {
        setSize(300, 300);
        setVisible(true);

        addMouseListener(this);
        addMouseMotionListener(this);


    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        x1 = e.getX();
        y1= e.getY();
//        System.out.println(x1);
    }

    public void mouseReleased(MouseEvent e) {
        x2 = e.getX();
        y2=e.getY();
//        System.out.println(x2);
        if (x2 > x1) {
            System.out.println("right");
        }
        if (x1 > x2) {
            System.out.println("left");
        }
        
        Graphics g =getGraphics();
        g.drawLine(x1, y1, x2, y2);
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    public static void main(String[] args) {
        new direction();
    }
}
