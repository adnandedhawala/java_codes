
import java.awt.Frame;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class bitop extends Frame{
    public static void main(String[] args) {
        int a= 128;
        int b = a>>1;
        System.out.println(b);
        int c = a>>3;
        System.out.println(c);
        int x = c<<1;
        System.out.println(x);
    }
}
