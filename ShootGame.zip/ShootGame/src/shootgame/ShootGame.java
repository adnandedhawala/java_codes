/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shootgame;

import com.sun.java.accessibility.util.AWTEventMonitor;
import static com.sun.java.accessibility.util.AWTEventMonitor.addActionListener;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lenovo
 */
public class ShootGame extends Frame implements ActionListener, KeyListener, Runnable {

    int bx1 = 120, bx2 = 240, by1 = 180, by2 = 180;
    static final int BOX_WIDTH = 400, BOX_HIEGHT = 400;
    Color c = Color.RED, c1 = Color.GREEN;
    int dx = 2, dy = 2;
    int keyCode;
    

    public ShootGame() throws HeadlessException {
        MenuBar mb = new MenuBar();
        Menu pl_1 = new Menu("PLAYER_1");
        Menu pl_2 = new Menu("PLAYER_2");

        MenuItem mi_red = new MenuItem("RED");
        MenuItem mi_blue = new MenuItem("BLUE");
        MenuItem mi_cyan = new MenuItem("CYAN");

        MenuItem mi_red1 = new MenuItem("RED1");
        MenuItem mi_blue1 = new MenuItem("BLUE1");
        MenuItem mi_cyan1 = new MenuItem("CYAN1");

        pl_1.add(mi_red);
        pl_1.add(mi_blue);
        pl_1.add(mi_cyan);

        pl_2.add(mi_red1);
        pl_2.add(mi_blue1);
        pl_2.add(mi_cyan1);

        mb.add(pl_1);
        mb.add(pl_2);
        setMenuBar(mb);

        mi_red.addActionListener(this);
        mi_blue.addActionListener(this);
        mi_cyan.addActionListener(this);

        mi_red1.addActionListener(this);
        mi_blue1.addActionListener(this);
        mi_cyan1.addActionListener(this);

        addActionListener(this);
        addKeyListener(this);

        setSize(BOX_WIDTH, BOX_HIEGHT);
        setVisible(true);

        Thread t = new Thread(this);
        t.start();

        

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String name = e.getActionCommand();
        if (name.equals("RED")) {
            c = Color.RED;
        }
        if (name.equals("BLUE")) {
            c = Color.BLUE;
        }

        if (name.equals("CYAN")) {
            c = Color.CYAN;
        }

        if (name.equals("RED1")) {
            c1 = Color.RED;
        }
        if (name.equals("BLUE1")) {
            c1 = Color.BLUE;
        }

        if (name.equals("CYAN1")) {
            c1 = Color.CYAN;
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        keyCode = e.getKeyCode();
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void update(Graphics g) {
        
        paint(g);
    }
    
    
    

    @Override
    public void run() {
        while (true) {
            
            
            
            if (keyCode == KeyEvent.VK_UP) {
            by1 += dy;
        }
        if (keyCode == KeyEvent.VK_DOWN) {
            by1 -= dy;
        }
        if (keyCode == KeyEvent.VK_RIGHT) {
            bx1 += dx;
        }
        if (keyCode == KeyEvent.VK_LEFT) {
            bx1 -= dx;
        }
        if (keyCode == KeyEvent.VK_W) {
            by2 += dy;
        }
        if (keyCode == KeyEvent.VK_S) {
            by2 -= dy;
        }
        if (keyCode == KeyEvent.VK_D) {
            bx2 += dx;
        }
        if (keyCode == KeyEvent.VK_A) {
            bx2 -= dx;
        }

        Graphics g1 = getGraphics();
        g1.setColor(c);
        g1.fillOval(bx1, by1, 40, 40);
        g1.setColor(c1);
        g1.fillOval(bx2, by2, 40, 40);
        
            try {
                Thread.sleep(20);
            } catch (InterruptedException ex) {
                Logger.getLogger(ShootGame.class.getName()).log(Level.SEVERE, null, ex);
            }
            
         g1.setColor(Color.WHITE);
        g1.fillOval(bx1, by1, 40, 40);
        g1.fillOval(bx2, by2, 40, 40);    
        //repaint();
        }
    }

    public static void main(String[] args) {
        new ShootGame();

    }

}
