
import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class MTserver {

    MTserver() throws Exception {
        ServerSocket ss = new ServerSocket(9999);
        while (true) {
            System.out.println("Waiting for a connection");
            Socket s = ss.accept();
            ClientHandle ch = new ClientHandle(s);
        }
    }

    public static void main(String[] args) {
        try {
            MTserver obj = new MTserver();
        } catch (Exception ex) {
            Logger.getLogger(MTserver.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

class ClientHandle extends Thread {

    Socket s;//this s is different from s used in MT server class;that s is accepted as a parameter in client constructor;

    ClientHandle(Socket s) {
        this.s = s;
        start();

    }

    public void run() {
        while (true) {

            try {
                System.out.println("in run" + s.getPort());
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(ClientHandle.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
